// Copyright (c) Microsoft Corporation.
// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception

// _Dtento function -- IEEE 754 version

#include "xxdftype.hpp"
#include "xxxdtent.hpp"
